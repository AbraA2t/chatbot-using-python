import presetIcons from "@unocss/preset-icons";

export default defineNuxtConfig({
	modules: ["@pinia/nuxt", "@unocss/nuxt"],
	app: {
		head: {
			charset: "utf-16",
			viewport: "width=500, initial-scale=1",
			title: "Digital Qrcode Tickets",
			meta: [{ name: "description", content: "Get Qrcode tickets site" }],
		},
		pageTransition: { name: "page", mode: "out-in" },
	},
	unocss: {
		icons: true,
		presets: [presetIcons({})],
	},
});
